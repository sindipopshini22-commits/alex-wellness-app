import { useState } from "react";
import { Link } from "react-router-dom";
import {
  BookOpen,
  ChevronRight,
  CircleHelp,
  Feather,
  Heart,
  Home,
  Menu,
  MessageCircle,
  MoreHorizontal,
  NotebookPen,
  Plus,
  Settings,
  Sparkles,
  Target,
  X,
} from "lucide-react";

const navItems = [
  { label: "Today", icon: Home, active: true },
  { label: "Conversations", icon: MessageCircle },
  { label: "Journal", icon: NotebookPen },
  { label: "Classroom", icon: BookOpen },
];

const prompts = [
  "I feel a little overwhelmed today",
  "Help me understand what I’m feeling",
  "Can we do a grounding exercise?",
];

export default function Dashboard() {
  const [message, setMessage] = useState("");
  const [showMenu, setShowMenu] = useState(false);
  const [mood, setMood] = useState<string | null>(null);

  return (
    <main className="min-h-screen bg-[#f7f6f2] text-[#24332f]">
      <div className="flex min-h-screen">
        <aside className={`fixed inset-y-0 left-0 z-30 flex w-[272px] flex-col border-r border-[#e5e6df] bg-[#fbfaf7] p-6 transition-transform lg:relative lg:translate-x-0 ${showMenu ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#273b35] text-[#d9f28b]"><Sparkles className="h-4 w-4" /></div>
              <span className="font-display text-xl font-semibold tracking-[-0.04em]">alex</span>
            </Link>
            <button onClick={() => setShowMenu(false)} className="rounded-lg p-2 text-[#88918b] hover:bg-[#eef0e9] lg:hidden"><X className="h-4 w-4" /></button>
          </div>

          <div className="mt-12 space-y-1">
            <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-[#9aa19c]">Your space</p>
            {navItems.map(({ label, icon: Icon, active }) => (
              <button key={label} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold transition ${active ? "bg-[#eaf1e4] text-[#486342]" : "text-[#7b857e] hover:bg-[#f0f1ec] hover:text-[#3e5047]"}`}>
                <Icon className="h-[18px] w-[18px]" strokeWidth={active ? 2.2 : 1.8} />
                {label}
                {label === "Conversations" && <span className="ml-auto rounded-full bg-[#e7e8e1] px-2 py-0.5 text-[10px] text-[#8b938c]">3</span>}
              </button>
            ))}
          </div>

          <div className="mt-auto space-y-1">
            <button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-[#7b857e] transition hover:bg-[#f0f1ec] hover:text-[#3e5047]"><CircleHelp className="h-[18px] w-[18px]" strokeWidth={1.8} />How Alex works</button>
            <button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-[#7b857e] transition hover:bg-[#f0f1ec] hover:text-[#3e5047]"><Settings className="h-[18px] w-[18px]" strokeWidth={1.8} />Settings</button>
            <div className="mt-5 flex items-center gap-3 border-t border-[#e6e7e0] px-3 pt-5">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#dce9d2] text-sm font-bold text-[#66804a]">C</div>
              <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-[#3e5047]">Your space</p><p className="text-xs text-[#9aa19c]">Private account</p></div>
              <MoreHorizontal className="h-4 w-4 text-[#9aa19c]" />
            </div>
          </div>
        </aside>

        {showMenu && <button aria-label="Close navigation" onClick={() => setShowMenu(false)} className="fixed inset-0 z-20 bg-[#273b35]/20 lg:hidden" />}

        <section className="flex min-w-0 flex-1 flex-col">
          <header className="flex h-[76px] items-center justify-between border-b border-[#e5e6df] bg-[#f9f8f5]/80 px-5 backdrop-blur sm:px-8 lg:px-12">
            <button onClick={() => setShowMenu(true)} className="rounded-xl p-2 text-[#617067] hover:bg-white lg:hidden"><Menu className="h-5 w-5" /></button>
            <div className="hidden items-center gap-2 text-sm text-[#7d8780] sm:flex"><span className="h-2 w-2 rounded-full bg-[#9bbd52]" />Your space is private</div>
            <div className="flex items-center gap-3 sm:ml-auto">
              <span className="hidden text-right sm:block"><span className="block text-xs font-semibold text-[#6c7770]">Sunday, October 20</span><span className="block text-xs text-[#9aa19c]">A moment for yourself</span></span>
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#dce9d2] text-sm font-bold text-[#66804a]">C</div>
            </div>
          </header>

          <div className="mx-auto w-full max-w-[1180px] flex-1 px-5 py-8 sm:px-8 lg:px-12 lg:py-12">
            <div className="grid gap-7 xl:grid-cols-[minmax(0,1fr)_320px]">
              <div>
                <div className="mb-9 flex items-start justify-between">
                  <div><p className="mb-2 text-sm font-medium text-[#8b9c62]">Good morning, Cindy</p><h1 className="font-display text-4xl font-medium tracking-[-0.05em] text-[#273b35] sm:text-5xl">How are you arriving today?</h1></div>
                  <div className="hidden h-12 w-12 items-center justify-center rounded-2xl bg-[#eaf1e4] text-[#75974b] sm:flex"><Feather className="h-5 w-5" /></div>
                </div>

                <div className="rounded-[1.75rem] bg-[#dce9d2] p-6 sm:p-8">
                  <div className="flex items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-[#69805d]">Daily check-in</p><h2 className="mt-2 font-display text-2xl tracking-[-0.04em] text-[#304639]">A quick moment to notice.</h2></div><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/60 text-[#76924f]"><Heart className="h-5 w-5" /></div></div>
                  <p className="mt-3 max-w-md text-sm leading-6 text-[#637662]">There&apos;s no need to fix anything. Just notice what feels most true right now.</p>
                  <div className="mt-7 flex flex-wrap gap-2">
                    {["Heavy", "Low", "Okay", "Good", "Bright"].map((item) => <button key={item} onClick={() => setMood(item)} className={`rounded-full border px-4 py-2 text-sm font-medium transition ${mood === item ? "border-[#779843] bg-[#779843] text-white" : "border-white/70 bg-white/50 text-[#607460] hover:bg-white/80"}`}>{item}</button>)}
                  </div>
                </div>

                <div className="mt-9"><div className="mb-4 flex items-center justify-between"><h2 className="font-display text-2xl tracking-[-0.04em] text-[#304639]">Start wherever you are</h2><button className="text-xs font-semibold text-[#82905f] hover:text-[#526b42]">See all</button></div><div className="grid gap-3 md:grid-cols-3">{prompts.map((prompt, index) => <button key={prompt} onClick={() => setMessage(prompt)} className="group min-h-[136px] rounded-2xl border border-[#e5e6df] bg-white/70 p-5 text-left transition hover:-translate-y-0.5 hover:border-[#cbd8c1] hover:bg-white"><span className={`mb-5 flex h-9 w-9 items-center justify-center rounded-xl ${index === 0 ? "bg-[#f1e7d9] text-[#b18454]" : index === 1 ? "bg-[#e5edda] text-[#779843]" : "bg-[#e2edf0] text-[#6b9298]"}`}><MessageCircle className="h-4 w-4" /></span><span className="block text-sm font-semibold leading-5 text-[#4b5c52]">{prompt}</span><ChevronRight className="mt-3 h-4 w-4 text-[#a2aba3] transition group-hover:translate-x-1" /></button>)}</div></div>

                <div className="mt-9 rounded-2xl border border-[#e5e6df] bg-white/70 p-5 sm:p-6"><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f0f2ec] text-[#78905a]"><MessageCircle className="h-5 w-5" /></div><div><p className="text-sm font-semibold text-[#3e5047]">Talk with Alex</p><p className="text-xs text-[#8b958e]">A private conversation, whenever you need it.</p></div></div><div className="mt-5 flex items-center gap-3 rounded-xl border border-[#e5e6df] bg-[#fbfaf7] p-2 pl-4"><input value={message} onChange={(event) => setMessage(event.target.value)} placeholder="What&apos;s on your mind?" className="min-w-0 flex-1 bg-transparent text-sm text-[#3e5047] outline-none placeholder:text-[#a5ada7]" /><button className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#273b35] text-[#d9f28b] transition hover:bg-[#344c42]"><Plus className="h-4 w-4" /></button></div></div>
              </div>

              <aside className="space-y-5">
                <div className="rounded-[1.5rem] bg-[#273b35] p-6 text-white"><div className="flex items-center justify-between"><p className="text-xs font-bold uppercase tracking-[0.16em] text-[#b8cd87]">Your rhythm</p><Target className="h-4 w-4 text-[#b8cd87]" /></div><p className="mt-5 font-display text-3xl tracking-[-0.05em]">2 days</p><p className="mt-1 text-sm text-[#b8c4bb]">of showing up for yourself</p><div className="mt-6 flex gap-2">{["M", "T", "W", "T", "F", "S", "S"].map((day, index) => <div key={`${day}-${index}`} className={`flex h-7 w-7 items-center justify-center rounded-full text-[10px] font-semibold ${index < 2 ? "bg-[#d9f28b] text-[#415638]" : "bg-white/10 text-[#98a89e]"}`}>{day}</div>)}</div></div>
                <div className="rounded-[1.5rem] border border-[#e5e6df] bg-white/70 p-6"><div className="flex items-center justify-between"><h3 className="font-display text-xl tracking-[-0.04em] text-[#304639]">A gentle idea</h3><Sparkles className="h-4 w-4 text-[#9bbd52]" /></div><p className="mt-4 text-sm leading-6 text-[#76827a]">Try naming five things you can see, four you can touch, and three you can hear.</p><button className="mt-5 flex items-center gap-2 text-xs font-bold text-[#779843]">Try grounding <ChevronRight className="h-3.5 w-3.5" /></button></div>
                <div className="rounded-[1.5rem] border border-[#e5e6df] bg-[#f0f3ed] p-6"><p className="text-xs font-bold uppercase tracking-[0.16em] text-[#7b8a72]">Need more support?</p><p className="mt-3 text-sm leading-6 text-[#6d7971]">Alex is not a therapist or emergency service. In crisis, call or text <strong className="text-[#485c4c]">988</strong> in the US.</p><a href="https://findahelpline.com" target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-[#779843]">Find local help <ChevronRight className="h-3.5 w-3.5" /></a></div>
              </aside>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
